package pb;

public class test
{
	public static void main(String[] args)
	{
		pc.Car car1;
		car1 = new pc.Car();
		car1.show();
	}
}